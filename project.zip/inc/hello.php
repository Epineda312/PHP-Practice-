<?php 
/*
 * This file is our first "Hello World!" script
 * 
 * @author: Alena Holligan
*/
//our first php script
echo 'Hello World!'; //done
//echo 'Hello Treehouse!'; //done

//you can make a single line comment as long as you want, even wrapping to a new line, as long as you don't add a  hard return
//This is a second comment line

/*
line 1
line 2
line 3
*/
?>