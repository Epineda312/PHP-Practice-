<?php
$num_one = 1;
$num_two = 2;
$num_three = 3;

/*var_dump( $num_one );
var_dump( 1 );
var_dump( "1" );
var_dump( $num_one + $num_two - $num_three);*/

$distance_home = 1.2;
$distance_work = 2.5;

var_dump($distance_home + $distance_work + $num_three + .3);

$a = 5;
$b = 10;

var_dump($a * $b);
var_dump($a / $b);

$a = $a + 1;
var_dump($a);
$a++;
var_dump($a);
$a--;
var_dump($a);
var_dump($a--);
var_dump($a);
var_dump(--$a);
var_dump($a);
$a = $a + 5;
var_dump($a);
$a += 5;
var_dump($a);
?>